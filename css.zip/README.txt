A Pen created at CodePen.io. You can find this one at https://codepen.io/suez/pen/dPqxoM.

 Based on this - https://dribbble.com/shots/1945593-Login-Home-Screen

Right now svg-icons not appears in IE (css animation). All 4 icons are hardcoded with numbers, just for fun :D